<?php mysql_connect('localhost','fsuser123','fsuser123') or die(mysql_error());
 mysql_select_db('feedback_system') or die(mysql_error());
?>


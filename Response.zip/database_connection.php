<?php

//database_connection.php

$connect = new PDO('mysql:host=localhost;dbname=feedback_system', 'fsuser123', 'fsuser123');



?>